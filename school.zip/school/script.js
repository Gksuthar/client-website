function displayData() {
  alert("View Button clicked!");
}
function saveDesign() {
  // Code to save the design details to local storage or server goes here
  alert('Design details saved!');
}
function saveDesign() {
  // Code to save the design details to local storage or server goes here
  alert('Design details saved!');
}
